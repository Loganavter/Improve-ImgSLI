# Welcome to Tkonverter!

This application is designed to convert and analyze exported Telegram chats, primarily for pre-processing data for Large Language Models (LLMs).

Use the navigation on the left to learn about specific features.
