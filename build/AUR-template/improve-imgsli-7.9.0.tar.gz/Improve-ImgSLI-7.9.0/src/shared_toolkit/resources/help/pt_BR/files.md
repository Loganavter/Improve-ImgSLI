# Gerenciamento de Arquivos

Para começar, **arraste e solte** seu arquivo `result.json` da exportação de dados do Telegram na janela principal do aplicativo.
