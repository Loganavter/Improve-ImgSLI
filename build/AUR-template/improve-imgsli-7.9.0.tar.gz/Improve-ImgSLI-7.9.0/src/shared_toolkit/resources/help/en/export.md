# Exporting

Click **"Save to file..."** to open the export dialog.

The final `.txt` file will respect all your selected formatting options and any date filters you have applied using the Analysis Chart or Calendar.
