# File Management

To begin, **drag and drop** your `result.json` file from a Telegram data export onto the main application window.
