# Bem-vindo ao Tkonverter!

Este aplicativo foi projetado para converter e analisar chats exportados do Telegram, principalmente para pré-processamento de dados para Modelos de Linguagem Grande (LLMs).

Use a navegação à esquerda para aprender sobre recursos específicos.
