# Exportação

Clique em **"Salvar em arquivo..."** para abrir o diálogo de exportação.

O arquivo `.txt` final respeitará todas as suas opções de formatação selecionadas e quaisquer filtros de data que você aplicou usando o Gráfico de Análise ou Calendário.
