# 文件管理

首先，将 Telegram 数据导出中的 `result.json` 文件**拖放**到主应用程序窗口中。
