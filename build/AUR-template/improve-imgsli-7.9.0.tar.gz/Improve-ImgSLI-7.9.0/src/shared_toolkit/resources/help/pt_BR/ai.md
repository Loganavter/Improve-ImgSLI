# Recursos de IA e Tokenizador

O Tkonverter pode calcular o número exato de tokens que seu chat usará com um modelo de IA específico. Isso requer a biblioteca **transformers**.

- Clique no ícone **Download** para abrir o **Gerenciador de Instalação**.
- De lá, você pode instalar as bibliotecas necessárias e baixar modelos de tokenizador do Hugging Face.
- Uma vez que um tokenizador é carregado, a análise mudará de contar caracteres para contar tokens.
