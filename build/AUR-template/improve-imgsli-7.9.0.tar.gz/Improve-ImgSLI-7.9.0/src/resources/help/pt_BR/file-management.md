## Gerenciamento de Arquivos

Conteúdo em português será fornecido em breve.
Enquanto isso, consulte a versão em inglês.


### Roda do mouse nas listas
- Role a roda do mouse sobre os menus suspensos das listas de imagens para alternar o item atualmente selecionado no respectivo lado (esquerda/direita).
- Você também pode rolar sobre o menu de Interpolação para alterar rapidamente o método de reamostragem.

### Classificações
- Além dos botões `[+]` e `[-]` ao lado de cada imagem, role a roda do mouse sobre o indicador de pontuação para aumentar ou diminuir a nota da imagem atual.
