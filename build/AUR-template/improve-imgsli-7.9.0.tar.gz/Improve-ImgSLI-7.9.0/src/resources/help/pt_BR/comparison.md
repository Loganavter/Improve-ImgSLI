## Comparação Básica

Conteúdo em português será fornecido em breve.
Enquanto isso, consulte a versão em inglês.


### Navegação com a roda do mouse
- Quando a Lupa estiver desativada, rolar a roda do mouse sobre a área de comparação alterna o item atualmente selecionado na lista do lado sob o cursor (esquerda/direita ou cima/baixo, dependendo da orientação da divisória).

### Controles da divisória
- Espessura da divisória: role a roda do mouse sobre o botão de Espessura da Divisória para ajustar o valor. Um pequeno popup numérico exibirá a espessura atual.
- Cor da divisória: clique no botão de Cor da Divisória para escolher uma cor.
