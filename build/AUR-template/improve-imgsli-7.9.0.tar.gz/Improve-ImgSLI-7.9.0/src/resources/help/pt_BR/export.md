## Exportando Resultados

Conteúdo em português será fornecido em breve.
Enquanto isso, consulte a versão em inglês.


### Salvamento Rápido vs Salvar Resultado
- Salvamento Rápido (Ctrl+S) usa suas últimas configurações de exportação e salva imediatamente, sem abrir o diálogo de Exportação.
- Salvar Resultado (Ctrl+Shift+S) abre o diálogo de Exportação, permitindo configurar formato, qualidade/compactação e opções de preenchimento de fundo antes de salvar.

### Bandeja do sistema e notificações ao salvar
- Após um salvamento bem-sucedido, o menu do ícone na bandeja oferece acesso rápido:
  - Abrir o último arquivo salvo (visível após o primeiro salvamento bem-sucedido)
  - Abrir a pasta do último salvamento
- Pode aparecer uma notificação do sistema ao salvar; clicar na notificação abre a pasta do último salvamento.
- Você pode alternar as notificações do sistema em Configurações.
