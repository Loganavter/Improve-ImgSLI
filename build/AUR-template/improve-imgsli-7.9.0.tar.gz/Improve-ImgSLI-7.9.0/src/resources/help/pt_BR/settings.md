## Configurações

Conteúdo em português será fornecido em breve.
Enquanto isso, consulte a versão em inglês.
