## Atalhos

Conteúdo em português será fornecido em breve.
Enquanto isso, consulte a versão em inglês.


### Atalhos de salvamento
- Ctrl+S — Salvamento Rápido usando suas últimas configurações de exportação, sem abrir o diálogo.
- Ctrl+Shift+S — Salvar Resultado com o diálogo de Exportação para configurar formato, qualidade/compactação e preenchimento de fundo.

### Controles do overlay de colagem
- Após pressionar Ctrl+V, aparece um overlay para escolher a direção de colagem da imagem.
- Use as teclas de Setas ou `WASD` para selecionar a direção; clique com o mouse para confirmar a posição.
- Pressione `Esc` para cancelar o overlay de colagem.
