## Introdução

Conteúdo em português será fornecido em breve.
Enquanto isso, o fallback para inglês está ativo.


### Integração com a bandeja do sistema

- Quando suportado pelo seu sistema operacional, o aplicativo exibe um ícone na bandeja para acesso rápido.
- O menu da bandeja oferece:
  - Mostrar/Ocultar janela
  - Abrir o último arquivo salvo (visível após o primeiro salvamento bem-sucedido)
  - Abrir a pasta do último salvamento
  - Sair
- Após um salvamento bem-sucedido, pode aparecer uma notificação do sistema; clicar na notificação abre a pasta do último salvamento.
- Você pode alternar as notificações do sistema em Configurações.
