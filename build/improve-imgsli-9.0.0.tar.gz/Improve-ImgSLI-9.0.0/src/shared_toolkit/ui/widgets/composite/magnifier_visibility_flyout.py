import logging

from PyQt6.QtWidgets import QHBoxLayout, QWidget

from shared_toolkit.ui.managers.flyout_timer_service import AnchoredFlyoutAutoHide
from shared_toolkit.ui.widgets.atomic.numbered_toggle_icon_button import (
    NumberedToggleIconButton,
)
from shared_toolkit.ui.widgets.composite.base_flyout import BaseFlyout

logger = logging.getLogger("ImproveImgSLI")

class MagnifierVisibilityFlyout(BaseFlyout):
    def __init__(self, parent_widget: QWidget):
        super().__init__(parent_widget)
        self._parent = parent_widget
        self._anchor_button = None

        self.h_layout = QHBoxLayout()
        self.h_layout.setContentsMargins(0, 0, 0, 0)
        self.h_layout.setSpacing(6)

        self.content_layout.addLayout(self.h_layout)

        self.btn_left = NumberedToggleIconButton(1, self.container)
        self.btn_center = NumberedToggleIconButton(2, self.container)
        self.btn_right = NumberedToggleIconButton(3, self.container)

        for b in (self.btn_left, self.btn_center, self.btn_right):
            self.h_layout.addWidget(b)

        self._count = 3
        self._auto_hide = AnchoredFlyoutAutoHide(
            flyout=self,
            anchor_getter=lambda: self._anchor_button,
            parent=self,
        )

        self.hide()

    def set_mode_and_states(
        self, show_center: bool, left_on: bool, center_on: bool, right_on: bool
    ):
        self._count = 3 if show_center else 2
        self.btn_center.setVisible(show_center)

        self.btn_left.setChecked(not left_on, emit_signal=False)
        self.btn_right.setChecked(not right_on, emit_signal=False)
        if show_center:
            self.btn_center.setChecked(not center_on, emit_signal=False)

        self.update_display_numbers(left_on, center_on, right_on, show_center)

        self.h_layout.invalidate()
        self.h_layout.activate()
        self.container.updateGeometry()
        self.adjustSize()

    def update_display_numbers(
        self, left_on: bool, center_on: bool, right_on: bool, show_center: bool
    ):
        self.btn_left.set_display_number(1)
        self.btn_center.set_display_number(2 if show_center else None)
        self.btn_right.set_display_number(3 if show_center else 2)

    def show_for_button(
        self, anchor_btn: QWidget, parent_widget: QWidget, hover_delay_ms: int = 0
    ):
        def _do_show():
            self._anchor_button = anchor_btn
            self.show_aligned(anchor_btn, "top")

        if hover_delay_ms > 0:
            QTimer.singleShot(hover_delay_ms, _do_show)
        else:
            _do_show()

    def schedule_auto_hide(self, ms: int):
        self._auto_hide.schedule(ms)

    def cancel_auto_hide(self):
        self._auto_hide.cancel()

    def hide(self):
        self.cancel_auto_hide()
        super().hide()

    def contains_global(self, global_pos) -> bool:
        from PyQt6.QtCore import QPointF

        if isinstance(global_pos, QPointF):
            pt = global_pos.toPoint()
        else:
            pt = global_pos

        return self.rect().contains(self.mapFromGlobal(pt))
