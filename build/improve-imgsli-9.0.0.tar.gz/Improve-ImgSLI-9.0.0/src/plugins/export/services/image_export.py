import logging
import os
import threading
from typing import Any, Optional

from PIL import Image

from core.store import Store
from domain.types import Color
from plugins.export.scene_builder import ExportSceneBuilder

logger = logging.getLogger("ImproveImgSLI")

try:
    import imagecodecs
    import numpy as np

    JXL_SUPPORTED = True
    logger.info("JXL export support: imagecodecs imported successfully")
except ImportError as e:
    JXL_SUPPORTED = False
    logger.warning(f"JXL export support: imagecodecs import failed - {e}")

class ExportService:

    def __init__(self, font_path_absolute: str, gpu_export_service=None):
        self.font_path_absolute = font_path_absolute
        self.gpu_export_service = gpu_export_service

    def export_image(
        self,
        store: Store,
        original_image1: Image.Image,
        original_image2: Image.Image,
        export_options: dict,
        render_context=None,
        magnifier_drawing_coords=None,
        cancel_event: Optional[threading.Event] = None,
        progress_callback: Optional[Any] = None,
    ) -> str:
        """
        Экспортирует изображение сравнения в файл.
        """
        if cancel_event and cancel_event.is_set():
            raise RuntimeError("Export canceled by user")

        if not original_image1 or not original_image2:
            raise ValueError("Full resolution images are not available for saving.")
        if not export_options.get("output_dir") or not export_options.get("file_name"):
            raise ValueError("Output directory or file name not specified.")

        if progress_callback:
            progress_callback(10)

        scene_builder = ExportSceneBuilder(store)
        current_render_context = render_context
        if current_render_context is None:
            image1_for_save, image2_for_save = scene_builder.build_resized_pair(
                original_image1, original_image2
            )
            current_render_context = scene_builder.build_render_context(
                image1_for_save,
                image2_for_save,
                source_image1=original_image1,
                source_image2=original_image2,
                magnifier_drawing_coords=magnifier_drawing_coords,
            )
        else:
            image1_for_save = current_render_context.image1
            image2_for_save = current_render_context.image2

        if progress_callback:
            progress_callback(30)

        if self.gpu_export_service is None:
            raise RuntimeError("GPU export service is not configured")

        final_img, _gpu_debug = self.gpu_export_service.render_image(
            store=store,
            render_context=current_render_context,
        )

        if final_img is None:
            raise ValueError("Failed to create the base image for saving.")

        if cancel_event and cancel_event.is_set():
            raise RuntimeError("Export canceled by user")

        if progress_callback:
            progress_callback(50)

        img_to_save = final_img
        if export_options.get("fill_background", False):
            bg_color_tuple = export_options.get("background_color")
            if bg_color_tuple:
                bg = Image.new("RGBA", final_img.size, bg_color_tuple)
                bg.paste(
                    final_img,
                    mask=final_img.split()[3] if final_img.mode == "RGBA" else None,
                )
                img_to_save = bg

        target_format = export_options.get("format", "PNG").upper()
        pil_format = "JPEG" if target_format == "JPG" else target_format
        output_dir = export_options["output_dir"]
        base_name = export_options["file_name"]
        is_quick_save = export_options.get("is_quick_save", False)
        ext = f".{target_format.lower().replace('jpeg', 'jpg')}"

        if is_quick_save:
            full_path = self._generate_unique_filepath(output_dir, base_name, ext)
        else:
            full_path = os.path.join(output_dir, f"{base_name}{ext}")

        os.makedirs(output_dir, exist_ok=True)

        save_kwargs = {}
        formats_with_alpha = {"PNG", "TIFF", "WEBP", "JXL"}
        if pil_format not in formats_with_alpha and img_to_save.mode == "RGBA":
            bg_color_tuple = export_options.get("background_color") or (
                255,
                255,
                255,
                255,
            )
            bg_flat = Image.new("RGBA", img_to_save.size, bg_color_tuple)
            bg_flat.paste(img_to_save, mask=img_to_save.split()[3])
            img_to_save = bg_flat.convert("RGB")

        if pil_format == "JPEG":
            save_kwargs["quality"] = int(export_options.get("quality", 95))
            try:
                comment_text = (export_options.get("comment_text") or "").strip()
                if comment_text and bool(export_options.get("include_metadata", True)):
                    exif = img_to_save.getexif()
                    exif[0x9286] = comment_text
                    save_kwargs["exif"] = exif.tobytes()
            except Exception:
                pass
        elif pil_format == "PNG":
            save_kwargs["compress_level"] = int(
                export_options.get("png_compress_level", 9)
            )
            save_kwargs["optimize"] = bool(export_options.get("png_optimize", True))
            try:
                comment_text = (export_options.get("comment_text") or "").strip()
                if comment_text and bool(export_options.get("include_metadata", True)):
                    import PIL.PngImagePlugin as PngImagePlugin

                    meta = PngImagePlugin.PngInfo()
                    meta.add_text("Comment", comment_text)
                    save_kwargs["pnginfo"] = meta
            except Exception:
                pass

        if cancel_event and cancel_event.is_set():
            raise RuntimeError("Export canceled by user")

        try:

            if pil_format == "JXL" and JXL_SUPPORTED:
                logger.info(f"Attempting to save JXL image: {full_path}")
                try:

                    img_array = np.array(img_to_save)
                    logger.debug(f"JXL array shape: {img_array.shape}")

                    quality = int(export_options.get("quality", 95))
                    logger.debug(f"JXL quality setting: {quality}")

                    if quality >= 100:

                        logger.debug("Saving JXL in lossless mode")
                        imagecodecs.imwrite(
                            full_path, img_array, codec="jxl", lossless=True
                        )
                    else:

                        distance = max(0.1, (100 - quality) / 10.0)
                        logger.debug(
                            f"Saving JXL in lossy mode with distance: {distance}"
                        )
                        imagecodecs.imwrite(
                            full_path, img_array, codec="jxl", distance=distance
                        )

                    logger.info(f"JXL image saved successfully: {full_path}")
                except Exception as e:
                    logger.error(f"Failed to save JXL image: {e}", exc_info=True)
                    raise
            else:

                with open(full_path, "wb") as f:

                    class _CancelableStream:
                        def __init__(self, base, cancel_ev):
                            self._b = base
                            self._e = cancel_ev

                        def write(self, b):
                            if self._e and self._e.is_set():
                                raise RuntimeError("Save canceled by user")
                            return self._b.write(b)

                        def flush(self):
                            return self._b.flush()

                        def close(self):
                            return self._b.close()

                        def seek(self, *args, **kwargs):
                            return self._b.seek(*args, **kwargs)

                        def tell(self):
                            return self._b.tell()

                        def writable(self):
                            return True

                        def readable(self):
                            return False

                        def seekable(self):
                            return True

                        def fileno(self):
                            return self._b.fileno()

                    stream = _CancelableStream(f, cancel_event)
                    img_to_save.save(stream, format=pil_format, **save_kwargs)
        except Exception:

            try:
                if os.path.exists(full_path):
                    os.remove(full_path)
            except Exception:
                pass
            raise

        if progress_callback:
            progress_callback(100)

        return full_path

    def quick_export(
        self,
        store: Store,
        original_image1: Image.Image,
        original_image2: Image.Image,
        cancel_event: Optional[threading.Event] = None,
        progress_callback: Optional[Any] = None,
    ) -> str:
        """
        Быстрый экспорт с использованием сохранённых в store настроек.
        """

        bg_color = getattr(
            store.settings, "export_background_color", Color(255, 255, 255, 255)
        )
        bg_color_tuple = (bg_color.r, bg_color.g, bg_color.b, bg_color.a)

        export_options = {
            "output_dir": store.settings.export_default_dir,
            "file_name": self._generate_base_filename(store),
            "format": store.settings.export_last_format or "PNG",
            "quality": store.settings.export_quality or 95,
            "fill_background": getattr(store.settings, "export_fill_background", False),
            "background_color": bg_color_tuple,
            "png_compress_level": getattr(
                store.settings, "export_png_compress_level", 9
            ),
            "png_optimize": True,
            "include_metadata": bool(
                getattr(store.settings, "export_comment_keep_default", False)
            ),
            "comment_text": (
                getattr(store.settings, "export_comment_text", "")
                if getattr(store.settings, "export_comment_keep_default", False)
                else ""
            ),
            "is_quick_save": True,
        }

        return self.export_image(
            store=store,
            original_image1=original_image1,
            original_image2=original_image2,
            export_options=export_options,
            cancel_event=cancel_event,
            progress_callback=progress_callback,
        )

    def _generate_base_filename(self, store: Store) -> str:
        import re

        name1 = (self._get_current_display_name(store, 1) or "image1").strip()
        name2 = (self._get_current_display_name(store, 2) or "image2").strip()

        def sanitize(s: str) -> str:
            s = re.sub(r'[\\/*?:"<>|]', "_", s)
            return s[:80]

        return f"{sanitize(name1)}_{sanitize(name2)}"

    def _get_current_display_name(self, store: Store, image_number: int) -> str:
        target_list, index = (
            (store.document.image_list1, store.document.current_index1)
            if image_number == 1
            else (store.document.image_list2, store.document.current_index2)
        )
        if 0 <= index < len(target_list):
            return target_list[index].display_name
        return ""

    def _generate_unique_filepath(
        self, directory: str, base_name: str, extension: str
    ) -> str:
        """
        Генерирует уникальный путь к файлу, добавляя номер, если файл уже существует.
        """
        full_path = os.path.join(directory, f"{base_name}{extension}")
        if not os.path.exists(full_path):
            return full_path

        counter = 1
        while True:
            new_name = f"{base_name} ({counter})"
            new_path = os.path.join(directory, f"{new_name}{extension}")
            if not os.path.exists(new_path):
                return new_path
            counter += 1
