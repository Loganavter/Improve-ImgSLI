import logging

from PyQt6.QtCore import QSettings
from PyQt6.QtGui import QColor

from core.constants import AppConstants
from core.store import Store
from domain.qt_adapters import hex_to_color, color_to_hex, qcolor_to_color
from domain.types import Point
from ui.canvas_features.magnifier import MagnifierStoreService
from ui.canvas_features.magnifier.store import (
    default_capture_size,
    default_magnifier_size,
    set_default_capture_size,
    set_default_magnifier_size,
)
from ui.canvas_infra.scene.property_access import (
    deserialize_canvas_feature_setting,
    read_canvas_feature_property,
    write_canvas_feature_property,
    serialize_canvas_feature_setting,
)
from ui.canvas_infra.scene.widget_registry import get_canvas_feature_properties

logger = logging.getLogger("ImproveImgSLI")

class SettingsManager:
    def __init__(self, organization_name, application_name):
        self.settings = QSettings(organization_name, application_name)

    def _get_setting(self, key, default, target_type):
        if not self.settings.contains(key):
            return default
        val = self.settings.value(key)
        try:
            if target_type == bool:
                return str(val).lower() == "true"
            if target_type == int:
                return int(float(val))
            if target_type == float:
                return float(val)
            return target_type(val)
        except:
            return default

    def load_all_settings(self, store: Store):
        v, s = store.viewport, store.settings
        render = v.render_config
        view = v.view_state
        scene_state = MagnifierStoreService(store)

        render.max_name_length = self._get_setting("max_name_length", 50, int)
        render.display_resolution_limit = self._get_setting(
            "display_resolution_limit", 2160, int
        )

        set_default_magnifier_size(
            view,
            self._get_setting("magnifier_size_relative", 0.4, float),
        )
        set_default_capture_size(
            view,
            self._get_setting("capture_size_relative", 0.1, float),
        )
        initial_spacing = self._get_setting(
            "magnifier_spacing_relative", AppConstants.DEFAULT_MAGNIFIER_SPACING_RELATIVE, float
        )
        view.movement_speed_per_sec = self._get_setting(
            "movement_speed_per_sec", 2.0, float
        )

        s.theme = self._get_setting("theme", "auto", str)
        s.current_language = self._get_setting("language", "en", str)
        s.ui_mode = self._get_setting("ui_mode", "beginner", str)
        s.debug_mode_enabled = self._get_setting("debug_mode_enabled", False, bool)
        s.system_notifications_enabled = self._get_setting(
            "system_notifications_enabled", True, bool
        )
        s.auto_crop_black_borders = self._get_setting(
            "auto_crop_black_borders", True, bool
        )
        s.video_recording_fps = self._get_setting("video_recording_fps", 60, int)
        v.session_data.image_state.auto_calculate_psnr = self._get_setting(
            "auto_calculate_psnr", False, bool
        )
        v.session_data.image_state.auto_calculate_ssim = self._get_setting(
            "auto_calculate_ssim", False, bool
        )

        render.font_size_percent = self._get_setting("font_size_percent", 100, int)
        render.font_weight = self._get_setting("font_weight", 0, int)
        render.text_alpha_percent = self._get_setting("text_alpha_percent", 100, int)
        render.file_name_color = hex_to_color(
            self._get_setting("filename_color", "#FFFF0000", str)
        )
        render.file_name_bg_color = hex_to_color(
            self._get_setting("filename_bg_color", "#50000000", str)
        )
        render.draw_text_background = self._get_setting("draw_text_background", True, bool)
        render.text_placement_mode = self._get_setting("text_placement_mode", "edges", str)
        render.include_file_names_in_saved = self._get_setting(
            "include_file_names_in_saved", False, bool
        )

        view.optimize_magnifier_movement = self._get_setting(
            "optimize_magnifier_movement", True, bool
        )

        main_interp = self._get_setting("interpolation_method", "BILINEAR", str)
        render.interpolation_method = main_interp
        render.zoom_interpolation_method = self._get_setting(
            "zoom_interpolation_method", "BILINEAR", str
        )
        logger.debug(
            "SettingsManager.load_all_settings interpolation main=%s zoom=%s",
            main_interp,
            render.zoom_interpolation_method,
        )

        magnifier_movement_interp = self._get_setting(
            "magnifier_movement_interpolation_method", None, str
        )
        laser_smoothing_interp = None

        if magnifier_movement_interp is None:
            movement_interp = self._get_setting(
                "movement_interpolation_method", "BILINEAR", str
            )
            magnifier_movement_interp = movement_interp
            laser_smoothing_interp = movement_interp

        render.magnifier_movement_interpolation_method = (
            magnifier_movement_interp
        )
        from ui.canvas_features.guides.state import get_guides_widget_state

        get_guides_widget_state(v.view_state).smoothing_interpolation_method = (
            laser_smoothing_interp or "BILINEAR"
        )

        render.movement_interpolation_method = magnifier_movement_interp

        self._load_canvas_feature_settings(v)

        default_magnifier = scene_state.ensure_active_magnifier(create_if_missing=False)
        if default_magnifier is not None:
            scene_state.move_object_source_position(default_magnifier.id, AppConstants.DEFAULT_CAPTURE_POS_RELATIVE)
            scene_state.set_active_magnifier_offset(AppConstants.DEFAULT_MAGNIFIER_OFFSET_RELATIVE)
            scene_state.set_active_magnifier_spacing(initial_spacing)
            scene_state.set_active_magnifier_size(default_magnifier_size(view))
            scene_state.set_active_capture_size(default_capture_size(view))

        s.window_width = self._get_setting("window_width", 1024, int)
        s.window_height = self._get_setting("window_height", 768, int)
        s.window_x = self._get_setting("window_x", 100, int)
        s.window_y = self._get_setting("window_y", 100, int)
        s.window_was_maximized = self._get_setting("window_was_maximized", False, bool)

        s.export_use_default_dir = self._get_setting(
            "export_use_default_dir", True, bool
        )
        s.export_default_dir = self._get_setting("export_default_dir", None, str)
        s.export_favorite_dir = self._get_setting("export_favorite_dir", None, str)
        s.export_last_format = self._get_setting("export_last_format", "PNG", str)
        s.export_quality = self._get_setting("export_quality", 95, int)
        s.export_fill_background = self._get_setting(
            "export_fill_background", False, bool
        )
        s.export_background_color = hex_to_color(
            self._get_setting("export_background_color", "#FFFFFFFF", str)
        )
        s.export_last_filename = self._get_setting("export_last_filename", "", str)
        s.export_png_compress_level = self._get_setting(
            "export_png_compress_level", 9, int
        )
        s.export_comment_text = self._get_setting("export_comment_text", "", str)
        s.export_comment_keep_default = self._get_setting(
            "export_comment_keep_default", False, bool
        )
        s.export_video_favorite_dir = self._get_setting(
            "export_video_favorite_dir", None, str
        )
        s.export_video_container = self._get_setting("export_video_container", "mp4", str)
        s.export_video_codec = self._get_setting(
            "export_video_codec", "h264 (AVC)", str
        )
        s.export_video_quality_mode = self._get_setting(
            "export_video_quality_mode", "crf", str
        )
        s.export_video_crf = self._get_setting("export_video_crf", 23, int)
        s.export_video_bitrate = self._get_setting(
            "export_video_bitrate", "8000k", str
        )
        s.export_video_preset = self._get_setting(
            "export_video_preset", "medium", str
        )
        s.export_video_pix_fmt = self._get_setting(
            "export_video_pix_fmt", "yuv420p", str
        )
        s.export_video_manual_args = self._get_setting(
            "export_video_manual_args",
            "-c:v libx264 -crf 23 -pix_fmt yuv420p",
            str,
        )

    def save_all_settings(self, store: Store):
        v, s = store.viewport, store.settings
        render = v.render_config
        view = v.view_state
        scene_state = MagnifierStoreService(store)
        active_magnifier = scene_state.get_active_or_first_magnifier()
        self._save_setting("max_name_length", render.max_name_length)
        self._save_setting("display_resolution_limit", render.display_resolution_limit)

        self._save_setting(
            "magnifier_size_relative",
            active_magnifier.size_relative if active_magnifier is not None else default_magnifier_size(view),
        )
        self._save_setting(
            "capture_size_relative",
            active_magnifier.capture_size_relative if active_magnifier is not None else default_capture_size(view),
        )
        self._save_setting(
            "magnifier_spacing_relative",
            active_magnifier.spacing_relative if active_magnifier is not None else AppConstants.DEFAULT_MAGNIFIER_SPACING_RELATIVE,
        )
        self._save_setting("movement_speed_per_sec", view.movement_speed_per_sec)

        self._save_setting("theme", s.theme)
        self._save_setting("language", s.current_language)
        self._save_setting("ui_mode", s.ui_mode)
        self._save_setting(
            "system_notifications_enabled", s.system_notifications_enabled
        )
        self._save_setting("auto_crop_black_borders", s.auto_crop_black_borders)
        self._save_setting("video_recording_fps", s.video_recording_fps)
        self._save_setting(
            "auto_calculate_psnr", store.viewport.session_data.image_state.auto_calculate_psnr
        )
        self._save_setting(
            "auto_calculate_ssim", store.viewport.session_data.image_state.auto_calculate_ssim
        )

        self._save_setting("font_size_percent", render.font_size_percent)
        self._save_setting("font_weight", render.font_weight)
        self._save_setting("text_alpha_percent", render.text_alpha_percent)
        self._save_setting("filename_color", color_to_hex(render.file_name_color))
        self._save_setting("filename_bg_color", color_to_hex(render.file_name_bg_color))
        self._save_setting("draw_text_background", render.draw_text_background)
        self._save_setting("text_placement_mode", render.text_placement_mode)
        self._save_setting("include_file_names_in_saved", render.include_file_names_in_saved)

        self._save_setting("optimize_magnifier_movement", view.optimize_magnifier_movement)
        self._save_setting("interpolation_method", render.interpolation_method)
        self._save_setting(
            "zoom_interpolation_method", render.zoom_interpolation_method
        )

        self._save_setting(
            "magnifier_movement_interpolation_method",
            render.magnifier_movement_interpolation_method,
        )
        self._save_setting(
            "movement_interpolation_method", render.movement_interpolation_method
        )

        self._save_canvas_feature_settings(v)

        self._save_setting("window_width", s.window_width)
        self._save_setting("window_height", s.window_height)
        self._save_setting("window_x", s.window_x)
        self._save_setting("window_y", s.window_y)
        self._save_setting("window_was_maximized", s.window_was_maximized)
        self._save_setting("export_use_default_dir", s.export_use_default_dir)
        self._save_setting("export_default_dir", s.export_default_dir)
        self._save_setting("export_favorite_dir", s.export_favorite_dir)
        self._save_setting("export_last_format", s.export_last_format)
        self._save_setting("export_quality", s.export_quality)
        self._save_setting("export_fill_background", s.export_fill_background)
        self._save_setting(
            "export_background_color", color_to_hex(s.export_background_color)
        )
        self._save_setting("export_last_filename", s.export_last_filename)
        self._save_setting("export_png_compress_level", s.export_png_compress_level)
        self._save_setting("export_comment_text", s.export_comment_text)
        self._save_setting(
            "export_comment_keep_default", s.export_comment_keep_default
        )
        self._save_setting("export_video_favorite_dir", s.export_video_favorite_dir)
        self._save_setting("export_video_container", s.export_video_container)
        self._save_setting("export_video_codec", s.export_video_codec)
        self._save_setting("export_video_quality_mode", s.export_video_quality_mode)
        self._save_setting("export_video_crf", s.export_video_crf)
        self._save_setting("export_video_bitrate", s.export_video_bitrate)
        self._save_setting("export_video_preset", s.export_video_preset)
        self._save_setting("export_video_pix_fmt", s.export_video_pix_fmt)
        self._save_setting("export_video_manual_args", s.export_video_manual_args)

        self.settings.sync()

    def _load_canvas_feature_settings(self, viewport_state) -> None:
        for prop in get_canvas_feature_properties():
            if not prop.setting_key or not self.settings.contains(prop.setting_key):
                continue
            raw_value = self.settings.value(prop.setting_key)
            channels = deserialize_canvas_feature_setting(prop, raw_value)
            write_canvas_feature_property(viewport_state, prop, channels)

    def _save_canvas_feature_settings(self, viewport_state) -> None:
        for prop in get_canvas_feature_properties():
            if not prop.setting_key:
                continue
            channels = read_canvas_feature_property(viewport_state, prop)
            raw_value = serialize_canvas_feature_setting(prop, channels)
            self._save_setting(prop.setting_key, raw_value)

    def _save_setting(self, key, value):
        if value is None:
            return
        self.settings.setValue(key, value)

    def is_first_run(self) -> bool:
        return self._get_setting("is_first_run", True, bool)

    def set_first_run_completed(self):
        self._save_setting("is_first_run", False)
