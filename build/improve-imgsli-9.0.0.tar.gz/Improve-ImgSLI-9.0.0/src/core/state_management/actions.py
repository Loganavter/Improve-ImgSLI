from core.state_management.action_base import Action, ActionType
from core.state_management.appearance_actions import (
    SetCachedDiffImageAction,
    SetDrawTextBackgroundAction,
    SetFileNameBgColorAction,
    SetFileNameColorAction,
    SetFontSizePercentAction,
    SetFontWeightAction,
    SetIncludeFileNamesInSavedAction,
    SetInterpolationMethodAction,
    SetMagnifierMovementInterpolationMethodAction,
    SetMaxNameLengthAction,
    SetMovementInterpolationMethodAction,
    SetTextAlphaPercentAction,
    SetTextPlacementModeAction,
)
from core.state_management.cache_actions import (
    ClearAllCachesAction,
    ClearImageSlotDataAction,
    InvalidateGeometryCacheAction,
    InvalidateRenderCacheAction,
)
from core.state_management.document_actions import (
    SetCurrentIndexAction,
    SetFullResImageAction,
    SetImagePathAction,
    SetOriginalImageAction,
)
from core.state_management.geometry_actions import (
    SetFixedLabelDimensionsAction,
    SetImageDisplayRectAction,
    SetMagnifierScreenCenterAction,
    SetMagnifierScreenSizeAction,
    SetPixmapDimensionsAction,
)
from core.state_management.interaction_actions import (
    SetDraggingCapturePointAction,
    SetDraggingSplitInMagnifierAction,
    SetDraggingSplitLineAction,
    SetInteractionSessionIdAction,
    SetInteractiveModeAction,
    SetLastHorizontalMovementKeyAction,
    SetLastSpacingMovementKeyAction,
    SetLastVerticalMovementKeyAction,
    SetPressedKeysAction,
    SetResizeInProgressAction,
    SetSpaceBarPressedAction,
    SetUserInteractingAction,
)
from core.state_management.session_actions import (
    SetAutoCalculatePsnrAction,
    SetAutoCalculateSsimAction,
    SetCachedScaledImageDimsAction,
    SetDisplayCacheImageAction,
    SetDisplayResolutionLimitAction,
    SetImageSessionImageAction,
    SetLastDisplayCacheParamsAction,
    SetPendingUnificationPathsAction,
    SetPsnrValueAction,
    SetScaledImageForDisplayAction,
    SetSsimValueAction,
    SetUnificationInProgressAction,
    SetZoomInterpolationMethodAction,
)
from core.state_management.settings_actions import (
    SetAutoCropBlackBordersAction,
    SetLanguageAction,
    SetUIModeAction,
)
from core.state_management.viewport_actions import (
    SetActiveMagnifierIdAction,
    SetCaptureSizeRelativeAction,
    SetChannelViewModeAction,
    SetDiffModeAction,
    SetHighlightedMagnifierElementAction,
    SetIsDraggingSliderAction,
    SetMagnifierInternalSplitAction,
    SetMagnifierOffsetRelativeAction,
    SetMagnifierOffsetRelativeVisualAction,
    SetMagnifierPositionAction,
    SetMagnifierSizeRelativeAction,
    SetMagnifierSpacingRelativeAction,
    SetMagnifierSpacingRelativeVisualAction,
    SetMagnifierVisibilityAction,
    SetMovementSpeedAction,
    SetOptimizeMagnifierMovementAction,
    SetShowingSingleImageModeAction,
    SetSplitPositionAction,
    SetSplitPositionVisualAction,
    ToggleFreezeMagnifierAction,
    ToggleMagnifierAction,
    ToggleMagnifierOrientationAction,
    ToggleOrientationAction,
    UpdateMagnifierCombinedStateAction,
)

__all__ = [name for name in globals() if name.endswith("Action")] + ["Action", "ActionType"]
